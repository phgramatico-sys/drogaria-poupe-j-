# Drogaria Poupe Já SBC – versão para a Vercel

```
index.html      → o site (a Vercel abre este arquivo na página inicial)
api/chat.js     → assistente de IA (vira o endereço /api/chat)
lib/prompt.js   → o que a IA sabe sobre a loja (edite aqui)
vercel.json     → configuração da Vercel
```

## Publicar
1. Envie **o conteúdo desta pasta** para o GitHub (o `index.html` precisa ficar na raiz do repositório, não dentro de outra pasta).
2. Na Vercel: **Add New → Project**, importe o repositório.
3. Em *Framework Preset* escolha **Other**. Deixe *Build Command* e *Output Directory* vazios e *Root Directory* como `./`.
4. Em **Settings → Environment Variables**, adicione `ANTHROPIC_API_KEY` com sua chave.
5. Faça um novo deploy (**Deployments → ⋯ → Redeploy**) para a chave valer.

Sem a chave, o site funciona normalmente e o chat usa as respostas próprias do site.
