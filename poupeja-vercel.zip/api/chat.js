// Função serverless da Vercel: POST /api/chat
// Conversa com o Claude (API da Anthropic) sem expor a chave no navegador.
// Configure ANTHROPIC_API_KEY em: Vercel → Project → Settings → Environment Variables.

const { SYSTEM_PROMPT } = require("../lib/prompt");

const MODEL = process.env.ANTHROPIC_MODEL || "claude-haiku-5-5";
const API_VERSION = process.env.ANTHROPIC_VERSION || "2026-10-21";
const MAX_TOKENS = Number(process.env.MAX_TOKENS) || 500;
const RATE_MAX = Number(process.env.RATE_LIMIT_MAX) || 20;
const RATE_WINDOW_MS = (Number(process.env.RATE_LIMIT_WINDOW_MIN) || 10) * 60_000;
const LIMITS = { messages: 16, chars: 1200 };

// Limite simples por IP (vale por instância da função; suficiente para um site pequeno)
const hits = new Map();
function rateLimited(ip) {
  const now = Date.now();
  const list = (hits.get(ip) || []).filter(t => now - t < RATE_WINDOW_MS);
  list.push(now);
  hits.set(ip, list);
  return list.length > RATE_MAX;
}

function sanitizeMessages(input) {
  if (!Array.isArray(input)) return null;
  const msgs = input
    .filter(m => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
    .map(m => ({ role: m.role, content: m.content.trim().slice(0, LIMITS.chars) }))
    .filter(m => m.content)
    .slice(-LIMITS.messages);
  while (msgs.length && msgs[0].role !== "user") msgs.shift();
  const merged = [];
  for (const m of msgs) {
    const last = merged[merged.length - 1];
    if (last && last.role === m.role) last.content += "\n" + m.content;
    else merged.push({ ...m });
  }
  if (!merged.length || merged[merged.length - 1].role !== "user") return null;
  return merged;
}

function sameOrigin(req) {
  const origin = req.headers.origin;
  if (!origin) return true;
  try { return new URL(origin).host === req.headers.host; } catch { return false; }
}

module.exports = async (req, res) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  if (req.method !== "POST") return res.status(405).json({ error: "Use POST" });
  if (!sameOrigin(req)) return res.status(403).json({ error: "Origem não permitida" });
  if (!process.env.ANTHROPIC_API_KEY) return res.status(503).json({ error: "IA não configurada (falta ANTHROPIC_API_KEY)" });

  const ip = String(req.headers["x-forwarded-for"] || "").split(",")[0].trim() || "?";
  if (rateLimited(ip)) return res.status(429).json({ error: "Muitas mensagens. Tente de novo em alguns minutos." });

  let body = req.body;
  if (typeof body === "string") { try { body = JSON.parse(body); } catch { body = null; } }
  const messages = sanitizeMessages(body && body.messages);
  if (!messages) return res.status(400).json({ error: "Envie messages: [{role:'user', content:'...'}]" });

  const agora = new Date().toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo", weekday: "long", day: "2-digit", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" });

  try {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 25_000);
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      signal: ctrl.signal,
      headers: {
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": API_VERSION,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: MAX_TOKENS,
        system: `${SYSTEM_PROMPT}\n\nData e hora atual em Brasília: ${agora}. Use isso só para informar se a loja física está aberta quando for relevante; o chat atende em qualquer horário.`,
        messages,
      }),
    });
    clearTimeout(timer);
    const data = await r.json().catch(() => ({}));
    if (!r.ok) {
      console.error("[chat] erro da API:", r.status, data?.error?.message);
      return res.status(502).json({ error: "Não foi possível responder agora." });
    }
    const reply = (data.content || []).filter(b => b.type === "text").map(b => b.text).join("\n").trim();
    return res.status(200).json({ reply: reply || "Desculpe, não consegui responder agora. Fale com a gente pelo WhatsApp (11) 98882-1494." });
  } catch (e) {
    console.error("[chat] falha:", e.name === "AbortError" ? "timeout" : e.message);
    return res.status(502).json({ error: "Não foi possível responder agora." });
  }
};
